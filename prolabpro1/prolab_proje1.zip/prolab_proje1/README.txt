180201074-Oğuz Narlı
190201054-Alperen Tan

Dosyanızı file_path stringinin içine giriniz(örn:"c://...//...//dosyaisim.txt").
Dosya içeriğinizi {{x1,y1},{x2,y2},..} şeklinde giriniz.
Arayüz çıktısı için graphics.h kütüphanesi kurulu olmak zorundadır.
Program Codeblocks v17.12'de test edilmiştir.
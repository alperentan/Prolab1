#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char *file_path="den.txt";

void read_coordinate(char *crd){
    int i=0;
    char cr;
    FILE *fp=fopen(file_path,"r");
    if(fp!=NULL){
        while(!feof(fp)){
            cr=fgetc(fp);
            if(cr!='{'&&cr!='}'&&cr!=','){
                crd[i]=cr;
                i++;
            }
        }

        fclose(fp);
    }
    else{
        printf("A problem occurs");
    }
}
int main() {
    char *coordinate;
    read_coordinate(coordinate);
    printf("%s",coordinate);
    return 0;
}